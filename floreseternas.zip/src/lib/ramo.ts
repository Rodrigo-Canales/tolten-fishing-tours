// Ramo 3D de tulipanes de limpiapipas (alambre de chenille afelpado) envuelto en papel kraft con lazo.
// También arma un tulipán solo, alambre por alambre, para la sección de scroll.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export interface Ramo {
  /** 0 = tulipán vacío, 1 = tulipán armado; de 1 a 2 pasa al ramo completo */
  armado: number;
  /** true muestra el ramo (portada) */
  modoRamo: boolean;
  pose: { x: number; y: number; escala: number; giro: number };
  activo: (v: boolean) => void;
}

let sem = 41;
const rnd = () => ((sem = (sem * 16807) % 2147483647) / 2147483647);
const ss = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// pelusa del chenille: ruido fino para el relieve
function texPelusa() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d')!;
  g.fillStyle = '#808080'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 9000; i++) {
    const x = rnd() * 256, y = rnd() * 256, l = 2 + rnd() * 5, a = rnd() * Math.PI;
    g.strokeStyle = rnd() > 0.5 ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.45)'; g.lineWidth = 0.8;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(12, 1);
  return t;
}
function texKraft() {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d')!;
  g.fillStyle = '#c9a27a'; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 4000; i++) { g.fillStyle = `rgba(${rnd() > 0.5 ? '90,60,30' : '255,240,220'},${0.05 + rnd() * 0.1})`; g.fillRect(rnd() * 512, rnd() * 512, 1 + rnd() * 2, 1 + rnd() * 6); }
  for (let i = 0; i < 18; i++) { g.strokeStyle = 'rgba(90,60,30,0.12)'; g.lineWidth = 1 + rnd() * 2; g.beginPath(); const x = rnd() * 512; g.moveTo(x, 0); g.lineTo(x + (rnd() - 0.5) * 80, 512); g.stroke(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping; return t;
}

const fondoVert = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const fondoFrag = `
  uniform float uT; uniform float uAspect; varying vec2 vUv;
  void main(){
    vec2 p = vUv; p.x *= uAspect;
    vec3 a = vec3(0.992, 0.957, 0.945), b = vec3(0.97, 0.83, 0.86);
    vec3 col = mix(a, b, smoothstep(0.1, 1.3, vUv.x * 0.7 + (1.0 - vUv.y) * 0.6));
    for (int i = 0; i < 5; i++) {
      float fi = float(i);
      vec2 c = vec2(fract(sin(fi * 3.1) * 17.3) * uAspect, fract(sin(fi * 5.7) * 29.1));
      c += 0.04 * vec2(sin(uT * 0.15 + fi), cos(uT * 0.12 + fi * 2.0));
      col = mix(col, vec3(1.0, 0.9, 0.93), smoothstep(0.35, 0.0, length(p - c)) * 0.35);
    }
    gl_FragColor = vec4(col, 1.0);
  }`;

const sheenDe = (hex: string) => new THREE.Color(hex).lerp(new THREE.Color('#ffffff'), 0.55);
function matChenille(color: string, pelusa: THREE.Texture) {
  return new THREE.MeshPhysicalMaterial({
    color, roughness: 0.95, metalness: 0, sheen: 1, sheenRoughness: 0.45, sheenColor: sheenDe(color),
    bumpMap: pelusa, bumpScale: 3,
  });
}
// tubo de chenille: un tubo con el radio ondulado y desordenado, como el alambre afelpado real
function alambre(curva: THREE.Curve<THREE.Vector3>, radio: number, segs: number, cerrado = false) {
  const g = new THREE.TubeGeometry(curva, segs, radio, 10, cerrado);
  const p = g.attributes.position as THREE.BufferAttribute, nrm = g.attributes.normal as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const k = (rnd() - 0.5) * radio * 0.55 + Math.sin(i * 0.7) * radio * 0.12;
    p.setXYZ(i, p.getX(i) + nrm.getX(i) * k, p.getY(i) + nrm.getY(i) * k, p.getZ(i) + nrm.getZ(i) * k);
  }
  g.computeVertexNormals();
  return g;
}
// un pétalo: lazo cerrado en forma de gota, en el plano XY, base en el origen
function curvaPetalo(alto: number, ancho: number) {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i < 24; i++) {
    const t = i / 24, a = t * Math.PI * 2;
    const x = Math.sin(a) * ancho * (0.55 + 0.45 * Math.sin(a / 2));
    const y = (1 - Math.cos(a)) * 0.5 * alto;
    pts.push(new THREE.Vector3(x, y, Math.sin(a / 2) * ancho * 0.25));
  }
  return new THREE.CatmullRomCurve3(pts, true, 'catmullrom', 0.5);
}
function curvaHoja(largo: number, ancho: number, lado: number) {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i < 20; i++) {
    const t = i / 20, a = t * Math.PI * 2;
    const y = (1 - Math.cos(a)) * 0.5 * largo;
    const x = Math.sin(a) * ancho * Math.sin(Math.PI * y / largo) + lado * Math.pow(y / largo, 2) * 0.35;
    pts.push(new THREE.Vector3(x, y, 0));
  }
  return new THREE.CatmullRomCurve3(pts, true, 'catmullrom', 0.5);
}


// ---------- rosa de cinta de satín ----------
// Una cinta enrollada en espiral: el radio crece hacia afuera, las vueltas externas se abren
// y el borde superior se dobla hacia afuera como pétalo.
function geoCinta(vueltas = 3.5, N = 320, M = 8, escala = 1) {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  for (let i = 0; i <= N; i++) {
    const u = i / N, th = u * vueltas * Math.PI * 2;
    const r = (0.018 + 0.2 * Math.pow(u, 0.7)) * escala;
    // lóbulos de pétalo: 5 por vuelta, más marcados afuera
    const petalo = 1 + 0.13 * u * Math.pow(Math.abs(Math.sin(th * 1.25)), 1.5);
    const alto = (0.22 + 0.07 * u) * escala * Math.min(1, u / 0.03 + 0.3) * Math.min(1, (1 - u) / 0.04 + 0.4);
    const y0 = (-0.03 - 0.11 * u) * escala;
    const abre = (0.015 + 0.1 * Math.pow(u, 1.5)) * escala;
    for (let j = 0; j <= M; j++) {
      const v = j / M;
      const rizo = 0.04 * escala * u * Math.pow(Math.max(0, (v - 0.7) / 0.3), 2);
      const rad = r * petalo + abre * v * v + rizo;
      const y = y0 + v * alto - 0.02 * escala * u * Math.pow(Math.max(0, (v - 0.85) / 0.15), 2);
      pos.push(Math.cos(th) * rad, y, Math.sin(th) * rad);
      uv.push(u * 6, v);
    }
  }
  for (let i = 0; i < N; i++) for (let j = 0; j < M; j++) {
    const a = i * (M + 1) + j, b = a + M + 1;
    idx.push(a, b, a + 1, b, b + 1, a + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx); g.computeVertexNormals();
  return g;
}
function texTrama() {
  const c = document.createElement('canvas'); c.width = 64; c.height = 256;
  const g = c.getContext('2d')!;
  g.fillStyle = '#808080'; g.fillRect(0, 0, 64, 256);
  for (let y = 0; y < 256; y += 2) { g.fillStyle = `rgba(${y % 4 ? '255,255,255' : '0,0,0'},0.18)`; g.fillRect(0, y, 64, 1); }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
const trama = texTrama();
function matSaten(color: string) {
  return new THREE.MeshPhysicalMaterial({
    color, roughness: 0.3, metalness: 0, sheen: 0.9, sheenRoughness: 0.35, sheenColor: sheenDe(color),
    clearcoat: 0.25, clearcoatRoughness: 0.3, anisotropy: 0.7, bumpMap: trama, bumpScale: 0.4, side: THREE.DoubleSide,
  });
}
function geoHojaCinta(largo = 0.5, ancho = 0.17) {
  const sh = new THREE.Shape();
  sh.moveTo(0, 0); sh.quadraticCurveTo(ancho, largo * 0.45, 0, largo); sh.quadraticCurveTo(-ancho, largo * 0.45, 0, 0);
  const g = new THREE.ShapeGeometry(sh, 16);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setZ(i, -Math.abs(x) * 0.5 + (y / largo) * (y / largo) * 0.12); }
  g.computeVertexNormals();
  return g;
}
type Rosa = { g: THREE.Group; tubos: { mesh: THREE.Mesh; ini: number; fin: number }[] };
function crearRosa(color: string, matVerde: THREE.Material, alturaTallo = 2.4, curvatura = 0.2, tam = 1): Rosa {
  const g = new THREE.Group();
  const tallo = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0), new THREE.Vector3(curvatura * 0.3, alturaTallo * 0.45, 0), new THREE.Vector3(curvatura, alturaTallo, 0)]);
  const mTallo = new THREE.Mesh(new THREE.TubeGeometry(tallo, 50, 0.022, 8, false), matVerde); g.add(mTallo);
  const cabeza = new THREE.Mesh(geoCinta(3.3 + rnd() * 0.4, 320, 8, tam), matSaten(color));
  cabeza.position.copy(tallo.getPoint(1)); cabeza.rotation.y = rnd() * 6; g.add(cabeza);
  const tubos: Rosa['tubos'] = [{ mesh: cabeza, ini: 0, fin: 0.68 }, { mesh: mTallo, ini: 0.68, fin: 0.84 }];
  const matHoja = matSaten('#3f7f3c');
  [1, -1].forEach((lado, j) => {
    const h = new THREE.Mesh(geoHojaCinta(0.5 + j * 0.08), matHoja);
    const pt = tallo.getPoint(0.72 - j * 0.12);
    h.position.copy(pt); h.rotation.set(0.2, j * 2.2, -lado * 0.9);
    g.add(h); tubos.push({ mesh: h, ini: 0.84 + j * 0.08, fin: 0.92 + j * 0.08 });
  });
  return { g, tubos };
}

type Tulipan = { g: THREE.Group; tubos: { mesh: THREE.Mesh; orden: number }[] };
function crearTulipan(color: string, pelusa: THREE.Texture, matVerde: THREE.Material, alturaTallo = 2.4, curvatura = 0.2): Tulipan {
  const g = new THREE.Group();
  const tubos: Tulipan['tubos'] = [];
  const mat = matChenille(color, pelusa);
  const R = 0.028;
  // tallo
  const tallo = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0), new THREE.Vector3(curvatura * 0.3, alturaTallo * 0.4, 0), new THREE.Vector3(curvatura, alturaTallo, 0)]);
  const mTallo = new THREE.Mesh(alambre(tallo, R, 60), matVerde); g.add(mTallo); tubos.push({ mesh: mTallo, orden: 5 });
  const cabeza = new THREE.Group(); cabeza.position.copy(tallo.getPoint(1)); g.add(cabeza);
  // tres pétalos externos y tres internos
  for (let k = 0; k < 6; k++) {
    const interno = k >= 3;
    const pet = new THREE.Mesh(alambre(curvaPetalo(interno ? 0.5 : 0.58, interno ? 0.15 : 0.19), R, 70, true), mat);
    const piv = new THREE.Group();
    piv.rotation.y = (k % 3) * (Math.PI * 2 / 3) + (interno ? Math.PI / 3 : 0);
    pet.rotation.x = interno ? -0.08 : -0.22; pet.position.z = interno ? 0.03 : 0.07;
    piv.add(pet); cabeza.add(piv);
    tubos.push({ mesh: pet, orden: k });
  }
  // dos hojas largas desde la base del tallo
  [1, -1].forEach((lado, j) => {
    const h = new THREE.Mesh(alambre(curvaHoja(1.1 + j * 0.2, 0.12, lado), R * 0.95, 60, true), matVerde);
    h.position.set(curvatura * 0.12, alturaTallo * 0.18 + j * 0.15, 0); h.rotation.set(0.15 * lado, j * 1.4, -lado * 0.25);
    g.add(h); tubos.push({ mesh: h, orden: 6 + j });
  });
  return { g, tubos };
}

export function crearRamo(canvas: HTMLCanvasElement): Ramo {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const escena = new THREE.Scene();
  const pm = new THREE.PMREMGenerator(renderer);
  escena.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
  escena.environmentIntensity = 0.5;

  const camara = new THREE.PerspectiveCamera(30, 1, 0.1, 120);
  camara.position.set(0, 1.6, 12); camara.lookAt(0, 1.6, 0);
  escena.add(camara);
  const uni = { uT: { value: 0 }, uAspect: { value: 1 } };
  const fondo = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: uni, vertexShader: fondoVert, fragmentShader: fondoFrag, depthWrite: false, toneMapped: false }));
  fondo.position.z = -60; fondo.renderOrder = -1; camara.add(fondo);

  const llave = new THREE.DirectionalLight('#fff4f0', 2.4); llave.position.set(-3, 6, 6); escena.add(llave);
  escena.add(new THREE.HemisphereLight('#ffffff', '#e9b7c4', 1.1));
  const contra = new THREE.DirectionalLight('#ffd6e0', 1.6); contra.position.set(4, 3, -5); escena.add(contra);

  const pelusa = texPelusa();
  const verde = matChenille('#4f8d42', pelusa);

  const raiz = new THREE.Group(); escena.add(raiz);
  const giro = new THREE.Group(); raiz.add(giro);

  // ---------- ramo ----------
  const ramo = new THREE.Group(); ramo.rotation.x = 0.18; giro.add(ramo);
  const colores = ['#c2203e', '#f39ab4', '#e14d77', '#fbe3ea', '#c2203e', '#f6b5c6', '#ffffff', '#e14d77', '#c2203e', '#f39ab4', '#fbe3ea'];
  const verdeTallo = new THREE.MeshStandardMaterial({ color: '#3f7f3c', roughness: 0.6 });
  colores.forEach((c, i) => {
    // ramo redondo: una al centro, anillo de 5 y anillo de 5 más abierto
    const anillo = i === 0 ? 0 : i <= 5 ? 1 : 2;
    const a = i === 0 ? 0 : ((i - (anillo === 1 ? 1 : 6)) / 5) * Math.PI * 2 + (anillo === 2 ? 0.6 : 0);
    const inc = anillo * 0.26;
    const t = crearRosa(c, verdeTallo, 2.55 - anillo * 0.12, 0, 1.25);
    t.g.position.set(0, -0.9, 0);
    t.g.rotation.set(Math.sin(a) * inc, 0, -Math.cos(a) * inc);
    ramo.add(t.g);
  });
  // papel kraft en cono, abierto adelante y con borde ondulado
  const conoGeo = (rTop: number, alto: number, abre: number, onda: number) => {
    const g = new THREE.CylinderGeometry(rTop, 0.06, alto, 72, 10, true, Math.PI * 0.5 + abre / 2, Math.PI * 2 - abre);
    const p = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const t = (y + alto / 2) / alto;
      const ang = Math.atan2(x, z);
      p.setY(i, y + t * t * onda * Math.sin(ang * 5) + t * t * 0.25 * Math.cos(ang));
      const k = 1 + 0.05 * Math.sin(ang * 13) * t;
      p.setX(i, x * k); p.setZ(i, z * k);
    }
    g.computeVertexNormals();
    return g;
  };
  const kraft = new THREE.Mesh(conoGeo(1.15, 2.6, 0.9, 0.12), new THREE.MeshStandardMaterial({ map: texKraft(), roughness: 0.9, side: THREE.DoubleSide }));
  kraft.position.y = -0.55; ramo.add(kraft);
  const papelRosa = new THREE.Mesh(conoGeo(1.0, 2.5, 1.4, 0.16), new THREE.MeshStandardMaterial({ color: '#f7cfd8', roughness: 0.7, side: THREE.DoubleSide, transparent: true, opacity: 0.92 }));
  papelRosa.position.y = -0.38; papelRosa.rotation.y = 0.3; ramo.add(papelRosa);
  // lazo de satín
  const satin = new THREE.MeshPhysicalMaterial({ color: '#e14d77', roughness: 0.3, clearcoat: 0.8, sheen: 0.5, sheenColor: new THREE.Color('#ffc2d2'), side: THREE.DoubleSide });
  const lazo = new THREE.Group(); lazo.position.set(0, -1.35, 0.52); ramo.add(lazo);
  [1, -1].forEach((l) => {
    const oreja = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.05, 10, 32), satin); oreja.scale.set(1.3, 0.75, 0.5); oreja.position.x = l * 0.25; oreja.rotation.z = l * 0.25; lazo.add(oreja);
    const cola = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.55, 0.015), satin); cola.position.set(l * 0.12, -0.3, 0.02); cola.rotation.z = l * 0.35; lazo.add(cola);
  });
  lazo.add(new THREE.Mesh(new THREE.SphereGeometry(0.08, 16, 12), satin));

  // ---------- tulipán solo, para armarlo ----------
  const solo = crearRosa('#e14d77', new THREE.MeshStandardMaterial({ color: '#3f7f3c', roughness: 0.6 }), 2.4, 0.12, 2.2);
  solo.g.position.y = -0.9; giro.add(solo.g);
  solo.tubos[0].mesh.rotation.x = 0.6; // inclinar la rosa hacia la cámara para ver la espiral
  solo.tubos.forEach((t) => { (t.mesh.userData as any).n = (t.mesh.geometry as THREE.BufferGeometry).index!.count; });

  // pétalos sueltos flotando (limpiapipas cortados) para dar vida
  const sueltos = Array.from({ length: 8 }, (_, i) => {
    const m = new THREE.Mesh(geoCinta(0.8, 60, 4, 1.6), matSaten(colores[i % colores.length]));
    m.position.set((rnd() - 0.5) * 9, (rnd() - 0.2) * 5, -2 - rnd() * 4); escena.add(m);
    return { m, f: rnd() * 6, base: m.position.clone() };
  });

  const estado: Ramo = {
    armado: 2, modoRamo: true,
    pose: { x: 0.68, y: 0.55, escala: 1, giro: 0 },
    activo: (v) => { corriendo = v; if (v) bucle(); },
  };

  let W = 1, H = 1;
  const medir = () => {
    W = canvas.clientWidth; H = canvas.clientHeight;
    renderer.setSize(W, H, false);
    camara.aspect = W / H; camara.updateProjectionMatrix();
    const alto = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * 60;
    fondo.scale.set(alto * camara.aspect * 1.02, alto * 1.02, 1);
    uni.uAspect.value = camara.aspect;
  };
  medir(); addEventListener('resize', medir);
  const raton = { x: 0, y: 0, sx: 0, sy: 0 };
  addEventListener('pointermove', (e) => { raton.x = e.clientX / innerWidth - 0.5; raton.y = e.clientY / innerHeight - 0.5; });
  const quieto = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reloj = new THREE.Clock();
  let corriendo = true, pedido = false;
  function bucle() { if (pedido) return; pedido = true; requestAnimationFrame(() => { pedido = false; if (corriendo) { cuadro(); bucle(); } }); }

  function cuadro() {
    const t = reloj.getElapsedTime();
    uni.uT.value = t;
    const a = estado.armado;
    // tulipán solo: cada alambre se dibuja en orden (pétalos, tallo, hojas)
    const f = Math.min(1, a);
    solo.tubos.forEach((tb) => {
      const k = ss(tb.ini, tb.fin, f);
      (tb.mesh.geometry as THREE.BufferGeometry).setDrawRange(0, Math.floor(((tb.mesh.userData as any).n * k) / 3) * 3);
      tb.mesh.visible = k > 0;
    });
    // del tulipán al ramo
    const aRamo = estado.modoRamo ? 1 : ss(1.0, 1.6, a);
    ramo.visible = aRamo > 0.01; solo.g.visible = aRamo < 0.99;
    ramo.scale.setScalar(Math.max(0.001, aRamo));
    solo.g.scale.setScalar(1 - aRamo * 0.6);

    const altoV = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * camara.position.length();
    const anchoV = altoV * camara.aspect;
    const p = estado.pose;
    const ajuste = Math.min(1, camara.aspect / 0.8);
    raiz.scale.setScalar(p.escala * ajuste);
    raiz.position.set((p.x - 0.5) * anchoV, (0.5 - p.y) * altoV + 0.3, 0);
    raton.sx += (raton.x - raton.sx) * 0.05; raton.sy += (raton.y - raton.sy) * 0.05;
    giro.rotation.y = p.giro + raton.sx * 0.6 + (quieto ? 0 : Math.sin(t * 0.4) * 0.25);
    giro.rotation.x = raton.sy * 0.12;
    giro.rotation.z = quieto ? 0 : Math.sin(t * 0.6) * 0.025;

    sueltos.forEach((s) => {
      s.m.position.set(s.base.x + Math.sin(t * 0.3 + s.f) * 0.3, s.base.y + Math.sin(t * 0.5 + s.f) * 0.4, s.base.z);
      s.m.rotation.set(t * 0.3 + s.f, t * 0.2 + s.f, s.f);
    });
    renderer.render(escena, camara);
  }
  bucle();
  return estado;
}
