// Dibujo SVG de un ramo: sirve para las tarjetas del catálogo y para la vista previa de "Arma tu ramo".
export const PAPELES: Record<string, { fondo: string; borde: string }> = {
  Kraft: { fondo: '#c9a27a', borde: '#9c7650' },
  Rosado: { fondo: '#f7cfd8', borde: '#e39aae' },
  Blanco: { fondo: '#fbf7f4', borde: '#d9cfd3' },
  Negro: { fondo: '#3a2f35', borde: '#1f181c' },
};
export const CINTAS: Record<string, string> = { Fucsia: '#e14d77', Rojo: '#c2203e', Blanco: '#ffffff', Dorado: '#d8b45a' };
export const COLORES_FLOR: Record<string, string> = {
  Rosado: '#f39ab4', Fucsia: '#e14d77', Rojo: '#c2203e', Blanco: '#fbf3f5', Lila: '#c6a4e8', Amarillo: '#f6cf4a', Celeste: '#9cc9ec', Durazno: '#f6b58f',
};

let s = 7;
const r = () => ((s = (s * 16807) % 2147483647) / 2147483647);

export function dibujarRamo(colores: string[], papel = 'Kraft', cinta = 'Fucsia', n = 6, semilla = 7): string {
  s = semilla;
  const P = PAPELES[papel] ?? PAPELES.Kraft, C = CINTAS[cinta] ?? CINTAS.Fucsia;
  const lista = colores.length ? colores : ['#f39ab4'];
  const flores: string[] = [], tallos: string[] = [];
  const cant = Math.max(1, n);
  for (let i = 0; i < cant; i++) {
    const t = cant === 1 ? 0.5 : i / (cant - 1);
    const fila = cant > 6 ? (i % 2) : 0;
    const x = 100 + (t - 0.5) * (cant > 6 ? 112 : 92) + (r() - 0.5) * 6;
    const y = 70 + Math.pow(Math.abs(t - 0.5) * 2, 2) * 22 + fila * 20 - (cant > 6 ? 6 : 0) + (r() - 0.5) * 6;
    const c = lista[i % lista.length];
    const rot = (t - 0.5) * 40;
    tallos.push(`<path d="M100 150 Q${(100 + x) / 2} ${(y + 150) / 2 + 10} ${x} ${y + 14}" stroke="#4f8d42" stroke-width="3.5" fill="none" stroke-linecap="round"/>`);
    flores.push(`<g transform="translate(${x} ${y}) rotate(${rot * 2})">
      <path d="M-14 4 Q-22 -2 -18 -10 Q-10 -6 -8 2 Z M14 4 Q22 -2 18 -10 Q10 -6 8 2 Z" fill="#3f7f3c"/>
      <circle r="13" fill="${c}" stroke="rgba(58,36,48,.35)" stroke-width="1.2"/>
      <path d="M0.5 -0.5 a2 2 0 1 1 -3 1.5 a4.5 4.5 0 1 1 7 -2 a7 7 0 1 1 -11 5 a9.5 9.5 0 1 1 14 -6" fill="none" stroke="rgba(58,36,48,.38)" stroke-width="1.3" stroke-linecap="round"/>
      <path d="M-6 -8 Q-2 -11 3 -9" fill="none" stroke="rgba(255,255,255,.6)" stroke-width="1.6" stroke-linecap="round"/>
    </g>`);
  }
  return `<svg viewBox="0 0 200 230" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <ellipse cx="100" cy="222" rx="60" ry="6" fill="rgba(58,36,48,.12)"/>
    <path d="M28 96 L100 218 L172 96 Q150 112 130 100 Q110 116 100 102 Q88 116 70 100 Q50 112 28 96 Z" fill="${P.fondo}" stroke="${P.borde}" stroke-width="2" stroke-linejoin="round" opacity=".55"/>
    ${tallos.join('')}${flores.join('')}
    <path d="M44 108 L100 218 L156 108 Q132 126 100 114 Q68 126 44 108 Z" fill="${P.fondo}" stroke="${P.borde}" stroke-width="2" stroke-linejoin="round"/>
    <path d="M100 118 L100 214" stroke="${P.borde}" stroke-width="1.2" opacity=".5"/>
    <g transform="translate(100 168)">
      <path d="M0 0 Q-22 -16 -26 -2 Q-22 12 0 0 Z" fill="${C}" stroke="rgba(58,36,48,.35)" stroke-width="1.2"/>
      <path d="M0 0 Q22 -16 26 -2 Q22 12 0 0 Z" fill="${C}" stroke="rgba(58,36,48,.35)" stroke-width="1.2"/>
      <path d="M-3 2 L-12 26 M3 2 L12 26" stroke="${C}" stroke-width="5" stroke-linecap="round"/>
      <circle r="5" fill="${C}" stroke="rgba(58,36,48,.35)" stroke-width="1.2"/>
    </g>
  </svg>`;
}
