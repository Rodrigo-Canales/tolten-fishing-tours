# Flores Eternas

Sitio de flores de limpiapipas y rosas de cinta (Astro + GSAP + Three.js + Lenis).

## Correr en local
npm install
npm run dev

## Editar contenido (src/data)
- catalogo.json: líneas, modelos y precios ("destacado": true sale en el inicio)
- fechas.json: fechas especiales y cierre de pedidos
- faq.json: preguntas frecuentes
- sitio.json: Instagram, WhatsApp, zonas de entrega, anticipación y abono
Precios y colores de "Arma tu ramo": src/pages/index.astro (cantidades) y src/lib/dibujo.ts (papeles, cintas, colores)
