# E.R Pastelería

Sitio de la pastelería (Astro + GSAP + Three.js + Lenis).

## Correr en local
npm install
npm run dev

## Editar contenido (src/data)
- carta.json: categorías, productos, precios y porciones
- sabores.json: sabores (también cambian los colores de la torta 3D)
- fechas.json: fechas especiales y cierre de pedidos (las pasadas se ocultan solas)
- faq.json: preguntas frecuentes
- sitio.json: WhatsApp, Instagram, horario, anticipación y abono
