// Torta 3D procedural: pedestal de loza, capas de bizcocho y relleno con un trozo cortado,
// crema, chorreado brillante, rosetas con boquilla de estrella, frutillas, frambuesas y macarons.
// Se desarma por capas con el scroll y cambia de sabor mezclando los colores.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export type Sabor = { colores: { bizcocho: string; relleno: string; crema: string; drip: string } };
export type Etiqueta = { id: string; ancla: THREE.Object3D };
export interface Torta {
  explosion: number;
  sabor: number;
  pose: { x: number; y: number; escala: number; giro: number; vaiven: number };
  etiquetas: Etiqueta[];
  proyectar: (o: THREE.Object3D) => { x: number; y: number };
  activo: (v: boolean) => void;
}

let sem = 21;
const rnd = () => ((sem = (sem * 16807) % 2147483647) / 2147483647);
const ss = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// miga del bizcocho: gris claro con poros, se tiñe con material.color
function texMiga() {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d')!;
  g.fillStyle = '#f2f2f2'; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 2600; i++) {
    const x = rnd() * 512, y = rnd() * 512, r = 0.6 + rnd() * 2.6;
    g.fillStyle = `rgba(${rnd() > 0.5 ? '255,255,255' : '120,110,100'},${0.15 + rnd() * 0.35})`;
    g.beginPath(); g.ellipse(x, y, r, r * (0.6 + rnd() * 0.6), rnd() * 3, 0, 7); g.fill();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
// crema alisada con espátula: vetas suaves horizontales
function texCrema() {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
  const g = c.getContext('2d')!;
  g.fillStyle = '#fafafa'; g.fillRect(0, 0, 1024, 256);
  for (let i = 0; i < 70; i++) {
    const y = rnd() * 256;
    g.strokeStyle = `rgba(${rnd() > 0.5 ? '255,255,255' : '200,195,190'},${0.2 + rnd() * 0.3})`;
    g.lineWidth = 1 + rnd() * 5; g.beginPath(); g.moveTo(0, y);
    for (let x = 0; x <= 1024; x += 64) g.lineTo(x, y + Math.sin(x * 0.01 + i) * 4);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function texFrutilla() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256;
  const g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#e23a3a'); gr.addColorStop(1, '#b3121f');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  for (let y = 10; y < 250; y += 18) for (let x = (y / 18) % 2 ? 9 : 0; x < 256; x += 18) {
    g.fillStyle = '#f2c94c'; g.beginPath(); g.ellipse(x, y, 1.8, 3, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(120,0,10,0.4)'; g.beginPath(); g.arc(x, y + 1, 3.5, 0, 7); g.fill();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const fondoVert = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const fondoFrag = `
  uniform float uT; uniform float uAspect; uniform vec3 uA; uniform vec3 uB;
  varying vec2 vUv;
  void main(){
    vec2 p = vUv; p.x *= uAspect;
    vec3 col = mix(uA, uB, smoothstep(0.0, 1.2, vUv.x * 0.6 + (1.0 - vUv.y) * 0.7));
    // círculos de luz suaves
    for (int i = 0; i < 6; i++) {
      float fi = float(i);
      vec2 c = vec2(fract(sin(fi * 12.9) * 43.7) * uAspect, fract(sin(fi * 7.3) * 91.1));
      c += 0.03 * vec2(sin(uT * 0.2 + fi), cos(uT * 0.17 + fi));
      float d = length(p - c);
      col += vec3(1.0, 0.97, 0.95) * smoothstep(0.32, 0.0, d) * 0.12;
    }
    gl_FragColor = vec4(col, 1.0);
  }`;

export function crearTorta(canvas: HTMLCanvasElement, sabores: Sabor[]): Torta {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const escena = new THREE.Scene();
  const pm = new THREE.PMREMGenerator(renderer);
  escena.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
  escena.environmentIntensity = 0.6;

  const camara = new THREE.PerspectiveCamera(28, 1, 0.1, 120);
  camara.position.set(0, 3.2, 13.5);
  camara.lookAt(0, 1.2, 0);
  escena.add(camara);

  const uni = { uT: { value: 0 }, uAspect: { value: 1 }, uA: { value: new THREE.Color('#fbf3ec') }, uB: { value: new THREE.Color('#f5c6b8') } };
  const fondo = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: uni, vertexShader: fondoVert, fragmentShader: fondoFrag, depthWrite: false, toneMapped: false }));
  fondo.position.z = -60; fondo.renderOrder = -1; camara.add(fondo);

  const sol = new THREE.DirectionalLight('#fff3ea', 2.4);
  sol.position.set(-4, 9, 6); sol.castShadow = true;
  sol.shadow.mapSize.set(1024, 1024); sol.shadow.camera.left = -4; sol.shadow.camera.right = 4; sol.shadow.camera.top = 6; sol.shadow.camera.bottom = -4; sol.shadow.bias = -0.0005; sol.shadow.radius = 6;
  escena.add(sol);
  escena.add(new THREE.HemisphereLight('#fff6f0', '#e8b3a6', 1.0));
  const borde = new THREE.DirectionalLight('#ffd9cf', 1.2); borde.position.set(5, 3, -4); escena.add(borde);

  const raiz = new THREE.Group(); escena.add(raiz);
  const giro = new THREE.Group(); raiz.add(giro);

  type Pieza = { obj: THREE.Object3D; base: THREE.Vector3; fuera: THREE.Vector3; rotBase: THREE.Euler; rotFuera: THREE.Euler };
  const piezas: Pieza[] = [];
  const agregar = (obj: THREE.Object3D, fuera: THREE.Vector3, rotFuera?: THREE.Euler) => {
    giro.add(obj);
    piezas.push({ obj, base: obj.position.clone(), fuera, rotBase: obj.rotation.clone(), rotFuera: rotFuera ?? obj.rotation.clone() });
    obj.traverse((o) => { if ((o as THREE.Mesh).isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return obj;
  };

  // ---------- materiales que cambian con el sabor ----------
  const miga = texMiga(), crema = texCrema();
  const mBizcocho = new THREE.MeshStandardMaterial({ map: miga, bumpMap: miga, bumpScale: 2, roughness: 0.9, side: THREE.DoubleSide });
  const mRelleno = new THREE.MeshStandardMaterial({ roughness: 0.45, side: THREE.DoubleSide });
  const mCrema = new THREE.MeshStandardMaterial({ map: crema, bumpMap: crema, bumpScale: 0.6, roughness: 0.55, side: THREE.DoubleSide });
  const mDrip = new THREE.MeshPhysicalMaterial({ roughness: 0.18, clearcoat: 1, clearcoatRoughness: 0.08, envMapIntensity: 1.2 });

  // ---------- pedestal de loza ----------
  const loza = new THREE.MeshPhysicalMaterial({ color: '#fbf7f2', roughness: 0.2, clearcoat: 1, clearcoatRoughness: 0.1 });
  const pedestal = new THREE.Mesh(new THREE.LatheGeometry([
    new THREE.Vector2(0, -1.15), new THREE.Vector2(0.75, -1.15), new THREE.Vector2(0.78, -1.1), new THREE.Vector2(0.55, -1.0),
    new THREE.Vector2(0.22, -0.75), new THREE.Vector2(0.16, -0.3), new THREE.Vector2(0.3, -0.12), new THREE.Vector2(1.75, -0.08),
    new THREE.Vector2(1.8, -0.02), new THREE.Vector2(1.72, 0.0), new THREE.Vector2(0, 0.0),
  ], 96), loza);
  agregar(pedestal, new THREE.Vector3(0, -0.9, 0));

  // ---------- capas con trozo cortado ----------
  const R = 1.25;
  const corte = Math.PI * 0.42;          // ancho del trozo que falta
  const inicio = Math.PI * 0.12;         // el corte mira a la cámara, un poco a la derecha
  const t0 = inicio + corte, largoT = Math.PI * 2 - corte;
  const plano = (r0: number, r1: number, y0: number, y1: number, ang: number) => {
    const g = new THREE.BufferGeometry();
    const sx = Math.sin(ang), sz = Math.cos(ang);
    const v = new Float32Array([r0 * sx, y0, r0 * sz, r1 * sx, y0, r1 * sz, r1 * sx, y1, r1 * sz, r0 * sx, y1, r0 * sz]);
    g.setAttribute('position', new THREE.BufferAttribute(v, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2));
    g.setIndex([0, 1, 2, 0, 2, 3]); g.computeVertexNormals();
    return g;
  };
  const capa = (y0: number, y1: number, mat: THREE.Material, conCrema = true) => {
    const grp = new THREE.Group();
    const h = y1 - y0;
    const cil = new THREE.Mesh(new THREE.CylinderGeometry(R, R, h, 96, 1, false, t0, largoT), [conCrema ? mCrema : mat, mat, mat]);
    cil.position.y = (y0 + y1) / 2; grp.add(cil);
    for (const a of [t0, t0 + largoT]) {
      grp.add(new THREE.Mesh(plano(0, R - 0.07, y0, y1, a), mat));
      if (conCrema) grp.add(new THREE.Mesh(plano(R - 0.07, R + 0.002, y0, y1, a), mCrema));
    }
    return grp;
  };
  const alturas = [[0, 0.44], [0.44, 0.56], [0.56, 1.0], [1.0, 1.12], [1.12, 1.56]];
  const ancla: Record<string, THREE.Object3D> = {};
  alturas.forEach(([y0, y1], i) => {
    const esRelleno = i % 2 === 1;
    const c = capa(y0, y1, esRelleno ? mRelleno : mBizcocho);
    const a = new THREE.Object3D(); a.position.set(Math.sin(t0 - corte / 2) * R * 0.6, (y0 + y1) / 2, Math.cos(t0 - corte / 2) * R * 0.6); c.add(a);
    if (i === 2) ancla.bizcocho = a;
    if (i === 3) ancla.relleno = a;
    agregar(c, new THREE.Vector3(0, y0 + i * 0.42, 0));
    c.position.y = 0; piezas[piezas.length - 1].fuera.y = i * 0.42;
  });
  // capa de crema superior
  const tapa = capa(1.56, 1.64, mCrema, false);
  const aCrema = new THREE.Object3D(); aCrema.position.set(-R, 1.6, 0.2); tapa.add(aCrema); ancla.crema = aCrema;
  agregar(tapa, new THREE.Vector3(0, 5 * 0.42, 0));

  // ---------- chorreado ----------
  const drip = new THREE.Group();
  const capaDrip = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.02, R - 0.02, 0.05, 96, 1, false, t0 + 0.02, largoT - 0.04), mDrip);
  capaDrip.position.y = 1.665; drip.add(capaDrip);
  const borde3 = new THREE.Mesh(new THREE.TorusGeometry(R, 0.045, 12, 120, largoT - 0.06), mDrip);
  borde3.rotation.x = Math.PI / 2;
  const bordeG = new THREE.Group(); bordeG.rotation.y = t0 + largoT - 0.03 - Math.PI / 2; bordeG.position.y = 1.64;
  bordeG.add(borde3); drip.add(bordeG);
  // gotas colgando, solo en la parte con torta
  for (let a = t0 + 0.08; a < t0 + largoT - 0.08; a += 0.11 + rnd() * 0.08) {
    const largo = 0.12 + Math.pow(rnd(), 1.6) * 0.55, r = 0.04 + rnd() * 0.025;
    const gota = new THREE.Mesh(new THREE.CapsuleGeometry(r, largo, 6, 12), mDrip);
    gota.position.set(Math.sin(a) * (R + 0.012), 1.64 - largo / 2, Math.cos(a) * (R + 0.012));
    drip.add(gota);
  }
  const aDrip = new THREE.Object3D(); aDrip.position.set(Math.sin(t0 + largoT * 0.85) * R, 1.45, Math.cos(t0 + largoT * 0.85) * R); drip.add(aDrip); ancla.cobertura = aDrip;
  agregar(drip, new THREE.Vector3(0, 2.35, 0));

  // ---------- decoración ----------
  const deco = new THREE.Group(); deco.position.y = 1.69;
  // rosetas con boquilla de estrella
  const perfilRoseta: THREE.Vector2[] = [];
  for (let i = 0; i <= 24; i++) { const t = i / 24; perfilRoseta.push(new THREE.Vector2(0.17 * Math.pow(1 - t, 0.75) * (1 + 0.25 * Math.sin(t * Math.PI * 3)), t * 0.3)); }
  const gRoseta = new THREE.LatheGeometry(perfilRoseta, 48);
  { const p = gRoseta.attributes.position as THREE.BufferAttribute; for (let i = 0; i < p.count; i++) { const x = p.getX(i), z = p.getZ(i), y = p.getY(i); const ang = Math.atan2(z, x) + y * 9; const k = 1 + 0.16 * Math.cos(ang * 8); p.setX(i, x * k); p.setZ(i, z * k); } gRoseta.computeVertexNormals(); }
  const mRoseta = new THREE.MeshStandardMaterial({ map: crema, roughness: 0.5, color: '#ffffff' });
  for (let a = t0 + 0.25; a < t0 + largoT - 0.15; a += 0.55) {
    const r = new THREE.Mesh(gRoseta, mRoseta); r.position.set(Math.sin(a) * (R - 0.2), 0, Math.cos(a) * (R - 0.2)); deco.add(r);
  }
  // frutillas
  const mFrutilla = new THREE.MeshPhysicalMaterial({ map: texFrutilla(), roughness: 0.35, clearcoat: 0.6 });
  const gFrutilla = new THREE.LatheGeometry([0, 0.06, 0.13, 0.17, 0.18, 0.16, 0.1, 0].map((r, i) => new THREE.Vector2(r, i * 0.05)), 32);
  const mHoja = new THREE.MeshStandardMaterial({ color: '#5f8f3a', roughness: 0.6, side: THREE.DoubleSide });
  const frutilla = () => {
    const g = new THREE.Group();
    const f = new THREE.Mesh(gFrutilla, mFrutilla); f.rotation.x = Math.PI; f.position.y = 0.35; g.add(f);
    for (let i = 0; i < 6; i++) { const h = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.16, 4), mHoja); const a = (i / 6) * Math.PI * 2; h.position.set(Math.cos(a) * 0.07, 0.36, Math.sin(a) * 0.07); h.rotation.set(Math.sin(a) * 1.2, 0, -Math.cos(a) * 1.2); g.add(h); }
    return g;
  };
  // frambuesa: racimo de esferitas
  const mFramb = new THREE.MeshPhysicalMaterial({ color: '#c0213d', roughness: 0.3, clearcoat: 0.5 });
  const gDrupa = new THREE.SphereGeometry(0.035, 10, 8);
  const frambuesa = () => {
    const g = new THREE.Group();
    for (let i = 0; i < 34; i++) { const t = i / 34, a = i * 2.4, y = t * 0.2, r = Math.sin(Math.PI * (0.15 + t * 0.85)) * 0.08; const d = new THREE.Mesh(gDrupa, mFramb); d.position.set(Math.cos(a) * r, y, Math.sin(a) * r); g.add(d); }
    return g;
  };
  // macaron: dos tapas, pie rugoso y relleno
  const macaron = (color: string, relleno: string) => {
    const g = new THREE.Group();
    const mT = new THREE.MeshStandardMaterial({ color, roughness: 0.55 });
    const tapaG = new THREE.SphereGeometry(0.3, 40, 16, 0, Math.PI * 2, 0, Math.PI / 2); tapaG.scale(1, 0.38, 1);
    const pie = new THREE.CylinderGeometry(0.3, 0.29, 0.05, 40);
    const arriba = new THREE.Mesh(tapaG, mT); arriba.position.y = 0.07;
    const pieA = new THREE.Mesh(pie, mT); pieA.position.y = 0.045;
    const abajo = new THREE.Mesh(tapaG, mT); abajo.rotation.x = Math.PI; abajo.position.y = -0.07;
    const pieB = new THREE.Mesh(pie, mT); pieB.position.y = -0.045;
    const rell = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.06, 40), new THREE.MeshStandardMaterial({ color: relleno, roughness: 0.4 }));
    g.add(arriba, pieA, abajo, pieB, rell);
    return g;
  };
  const mac1 = macaron('#f3a7b5', '#fff3ee'); mac1.position.set(-0.25, 0.32, -0.2); mac1.rotation.set(0.2, 0.4, 1.15); deco.add(mac1);
  const mac2 = macaron('#b9cf95', '#fff7e6'); mac2.position.set(0.25, 0.28, -0.45); mac2.rotation.set(-0.3, -0.2, 1.3); deco.add(mac2);
  const f1 = frutilla(); f1.position.set(-0.55, 0, 0.15); f1.rotation.z = 0.25; deco.add(f1);
  const f2 = frutilla(); f2.position.set(0.05, 0, 0.35); f2.rotation.set(-0.2, 1, -0.2); deco.add(f2);
  [[0.45, 0.1], [-0.15, -0.6], [0.6, -0.35], [-0.6, -0.35]].forEach(([x, z]) => { const fr = frambuesa(); fr.position.set(x, 0, z); deco.add(fr); });
  const aDeco = new THREE.Object3D(); aDeco.position.set(-0.25, 0.55, -0.2); deco.add(aDeco); ancla.decoracion = aDeco;
  agregar(deco, new THREE.Vector3(0, 1.69 + 2.9, 0), new THREE.Euler(0.15, 0.6, 0));

  // ---------- chispas de colores cayendo ----------
  const NC = 160;
  const chispas = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.025, 0.09, 3, 6), new THREE.MeshStandardMaterial({ roughness: 0.5 }), NC);
  const colores = ['#f3a7b5', '#b9cf95', '#f6d58b', '#ffffff', '#c9b6e8', '#8ccbe0'].map((c) => new THREE.Color(c));
  const cData = Array.from({ length: NC }, () => ({ x: (rnd() - 0.5) * 16, y: rnd() * 12 - 4, z: -2 - rnd() * 8, v: 0.15 + rnd() * 0.3, rx: rnd() * 6, ry: rnd() * 6, w: rnd() * 2 }));
  cData.forEach((_, i) => chispas.setColorAt(i, colores[i % colores.length]));
  escena.add(chispas);

  // ---------- estado ----------
  const estado: Torta = {
    explosion: 0, sabor: 0,
    pose: { x: 0.68, y: 0.55, escala: 1, giro: 0, vaiven: 1 },
    etiquetas: ['bizcocho', 'relleno', 'crema', 'cobertura', 'decoracion'].map((id) => ({ id, ancla: ancla[id] })),
    proyectar: (o) => { const v = new THREE.Vector3(); o.getWorldPosition(v); v.project(camara); return { x: (v.x * 0.5 + 0.5) * W, y: (-v.y * 0.5 + 0.5) * H }; },
    activo: (v) => { corriendo = v; if (v) bucle(); },
  };

  let W = 1, H = 1;
  const medir = () => {
    W = canvas.clientWidth; H = canvas.clientHeight;
    renderer.setSize(W, H, false);
    camara.aspect = W / H; camara.updateProjectionMatrix();
    const alto = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * 60;
    fondo.scale.set(alto * camara.aspect * 1.02, alto * 1.02, 1);
    uni.uAspect.value = camara.aspect;
  };
  medir(); addEventListener('resize', medir);

  const raton = { x: 0, y: 0, sx: 0, sy: 0 };
  addEventListener('pointermove', (e) => { raton.x = e.clientX / innerWidth - 0.5; raton.y = e.clientY / innerHeight - 0.5; });

  const quieto = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reloj = new THREE.Clock();
  let corriendo = true, pedido = false;
  const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpE = new THREE.Euler(), tmpV = new THREE.Vector3(), uno = new THREE.Vector3(1, 1, 1);
  const cA = new THREE.Color(), cB = new THREE.Color();
  const mezclar = (k: 'bizcocho' | 'relleno' | 'crema' | 'drip', s: number) => {
    const i = Math.min(sabores.length - 1, Math.floor(s)), j = Math.min(sabores.length - 1, i + 1);
    return cA.set(sabores[i].colores[k]).lerp(cB.set(sabores[j].colores[k]), ss(0.2, 0.8, s - i));
  };
  const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  function bucle() {
    if (pedido) return; pedido = true;
    requestAnimationFrame(() => { pedido = false; if (corriendo) { cuadro(); bucle(); } });
  }

  function cuadro() {
    const t = reloj.getElapsedTime();
    uni.uT.value = t;
    mBizcocho.color.copy(mezclar('bizcocho', estado.sabor));
    mRelleno.color.copy(mezclar('relleno', estado.sabor));
    mCrema.color.copy(mezclar('crema', estado.sabor));
    mDrip.color.copy(mezclar('drip', estado.sabor));

    const altoV = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * camara.position.length();
    const anchoV = altoV * camara.aspect;
    const p = estado.pose;
    const ajuste = Math.min(1, camara.aspect / 0.8);
    raiz.scale.setScalar(p.escala * ajuste);
    raiz.position.set((p.x - 0.5) * anchoV, (0.5 - p.y) * altoV * 0.9 + 1.2 - 0.9 * p.escala * ajuste, 0);
    raton.sx += (raton.x - raton.sx) * 0.05; raton.sy += (raton.y - raton.sy) * 0.05;
    giro.rotation.y = p.giro + (quieto ? 0 : Math.sin(t * 0.35) * 0.35 * p.vaiven) + raton.sx * 0.5;
    giro.rotation.x = raton.sy * 0.08;

    const k = ease(Math.min(1, Math.max(0, estado.explosion)));
    piezas.forEach((pz, i) => {
      pz.obj.position.lerpVectors(pz.base, pz.fuera, k);
      pz.obj.position.y += quieto ? 0 : Math.sin(t * 1.2 + i) * 0.03 * k;
      pz.obj.rotation.set(
        THREE.MathUtils.lerp(pz.rotBase.x, pz.rotFuera.x, k),
        THREE.MathUtils.lerp(pz.rotBase.y, pz.rotFuera.y, k),
        THREE.MathUtils.lerp(pz.rotBase.z, pz.rotFuera.z, k),
      );
    });

    if (!quieto) {
      cData.forEach((c, i) => {
        c.y -= c.v * 0.016; if (c.y < -5) c.y = 8;
        tmpE.set(c.rx + t * c.w, c.ry + t * c.w * 0.7, 0); tmpQ.setFromEuler(tmpE);
        tmpV.set(c.x + Math.sin(t * 0.5 + i) * 0.2, c.y, c.z);
        chispas.setMatrixAt(i, tmpM.compose(tmpV, tmpQ, uno));
      });
      chispas.instanceMatrix.needsUpdate = true;
    }
    renderer.render(escena, camara);
  }
  bucle();
  return estado;
}
