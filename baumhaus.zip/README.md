# Baumhaus Café Pastelería

Sitio del café (Astro + GSAP + Three.js + Lenis).

## Correr en local
npm install
npm run dev

## Editar contenido (src/data)
- carta.json: categorías, productos, precios, combos y lo que sale en la pizarra del inicio ("vitrina": true)
- catalogo.json: tortas a pedido, precio desde y colores del dibujo
- sitio.json: dirección, WhatsApp, Instagram y horario (el sitio muestra si está abierto ahora)
