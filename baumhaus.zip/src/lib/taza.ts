// Taza de café 3D con hojas de monstera flotando.
// El scroll controla la preparación: granos, espresso, leche y arte latte (tulipán) en la superficie.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export interface Taza {
  /** 0 granos, 0.25 espresso, 0.5 leche, 0.75 arte, 1 listo */
  proceso: number;
  /** 0 hojas en su lugar, 1 hojas abiertas hacia los bordes para dejar espacio al texto */
  apartar: number;
  pose: { x: number; y: number; escala: number; giro: number; inclinar: number };
  activo: (v: boolean) => void;
}

let sem = 33;
const rnd = () => ((sem = (sem * 16807) % 2147483647) / 2147483647);
const ss = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// ---------- superficie del café (shader) ----------
const liqVert = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const liqFrag = `
  uniform float uLeche; uniform float uArte; uniform float uT;
  varying vec2 vUv;
  float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453); }
  float n(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }
  float corazon(vec2 p, float s){ p /= s; float t = p.x * p.x + p.y * p.y - 1.0; float r = t * t * t - p.x * p.x * p.y * p.y * p.y; return 1.0 - smoothstep(-0.02, 0.02, r); }
  float gota(vec2 p, vec2 c, vec2 r){ vec2 q = (p - c) / r; return 1.0 - smoothstep(0.85, 1.0, length(q)); }
  void main(){
    vec2 p = vUv * 2.0 - 1.0;
    float rr = length(p);
    float ruido = n(p * 9.0 + uT * 0.15) * 0.5 + n(p * 23.0 - uT * 0.1) * 0.5;
    vec3 espresso = vec3(0.17, 0.09, 0.05);
    vec3 crema = vec3(0.62, 0.38, 0.2);
    vec3 latte = vec3(0.66, 0.42, 0.24);
    vec3 espuma = vec3(0.97, 0.93, 0.86);
    // espresso con crema dorada atigrada
    vec3 col = mix(crema * 0.85, crema * 1.15, ruido);
    col = mix(col, espresso, smoothstep(0.3, 1.05, rr) * 0.6);
    // la leche aclara el café desde el centro
    col = mix(col, latte * (0.9 + ruido * 0.2), smoothstep(0.0, 1.0, uLeche));
    float blob = 1.0 - smoothstep(0.2 + uLeche * 0.35, 0.55 + uLeche * 0.35, rr + (ruido - 0.5) * 0.25);
    col = mix(col, espuma, blob * uLeche * (1.0 - uArte));
    // arte latte: tulipán de tres capas que se dibuja de abajo hacia arriba
    vec2 q = p; q.y += 0.05;
    float c1 = gota(q, vec2(0.0, -0.42), vec2(0.42, 0.2));
    float c2 = gota(q, vec2(0.0, -0.14), vec2(0.52, 0.24));
    float c3 = corazon(q - vec2(0.0, 0.12), 0.34);
    float hueco1 = gota(q, vec2(0.0, -0.36), vec2(0.3, 0.13));
    float hueco2 = gota(q, vec2(0.0, -0.06), vec2(0.38, 0.15));
    float linea = (1.0 - smoothstep(0.012, 0.03, abs(q.x))) * step(-0.62, q.y) * step(q.y, 0.42);
    float a1 = smoothstep(0.0, 0.35, uArte), a2 = smoothstep(0.3, 0.65, uArte), a3 = smoothstep(0.6, 0.9, uArte), aL = smoothstep(0.88, 1.0, uArte);
    float arte = max(max(c1 * (1.0 - hueco1 * a2) * a1, c2 * (1.0 - hueco2 * a3) * a2), c3 * a3);
    arte = max(arte, linea * aL * 0.9);
    col = mix(col, espuma, arte * uArte);
    // borde de espuma
    col = mix(col, espuma * 0.95, smoothstep(0.86, 0.98, rr) * uLeche * 0.8);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }`;

// ---------- fondo: papel con luz que pasa entre hojas ----------
const fondoVert = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const fondoFrag = `
  uniform float uT; uniform float uAspect;
  varying vec2 vUv;
  float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453); }
  float n(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }
  void main(){
    vec2 p = vUv; p.x *= uAspect;
    vec3 papel = vec3(0.953, 0.918, 0.851);
    vec3 col = mix(papel, papel * vec3(0.92, 0.9, 0.85), smoothstep(0.2, 1.0, 1.0 - vUv.y));
    // sombras moteadas de hojas
    float m = n(p * 3.2 + vec2(uT * 0.05, uT * 0.03)) * 0.6 + n(p * 7.0 - vec2(uT * 0.04, 0.0)) * 0.4;
    col *= 1.0 - smoothstep(0.55, 0.75, m) * 0.12 * smoothstep(0.0, 0.6, vUv.x + vUv.y * 0.4);
    // luz cálida de ventana arriba a la izquierda
    col += vec3(1.0, 0.85, 0.6) * smoothstep(0.9, 0.0, length(vUv - vec2(0.1, 1.0))) * 0.08;
    gl_FragColor = vec4(col, 1.0);
  }`;

function texHoja() {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 512, 512, 0); gr.addColorStop(0, '#24502f'); gr.addColorStop(1, '#3f7a45');
  g.fillStyle = gr; g.fillRect(0, 0, 512, 512);
  g.strokeStyle = 'rgba(190,220,160,0.45)'; g.lineWidth = 5; g.beginPath(); g.moveTo(256, 512); g.lineTo(256, 20); g.stroke();
  g.lineWidth = 2;
  for (let i = 0; i < 9; i++) { const y = 460 - i * 48; for (const s of [-1, 1]) { g.beginPath(); g.moveTo(256, y); g.quadraticCurveTo(256 + s * 120, y - 40, 256 + s * 250, y - 120); g.stroke(); } }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
// monstera: contorno de corazón con cortes desde el borde y agujeros junto a la nervadura
function geoMonstera(): THREE.BufferGeometry {
  const sh = new THREE.Shape();
  const N = 120;
  const cortes = [0.12, 0.2, 0.29, 0.38, 0.62, 0.71, 0.8, 0.88];
  const pts: THREE.Vector2[] = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N, a = t * Math.PI * 2;
    // corazón: ancho en la base, punta arriba
    let r = 1 - 0.25 * Math.cos(a) ;
    const x = Math.sin(a) * r * 0.95, y = -Math.cos(a) * r * 1.05 + 0.15 * Math.sin(a * 0.5);
    let k = 1;
    for (const c of cortes) if (Math.abs(t - c) < 0.012) k = 0.45 + Math.abs(t - c) * 10;
    pts.push(new THREE.Vector2(x * k, y * k + (1 - k) * 0.1));
  }
  sh.setFromPoints(pts);
  for (const [x, y, rx, ry] of [[0.28, 0.1, 0.07, 0.15], [-0.28, 0.05, 0.07, 0.15], [0.25, -0.45, 0.06, 0.12], [-0.25, -0.4, 0.06, 0.12]]) {
    const hole = new THREE.Path(); hole.absellipse(x, y, rx, ry, 0, Math.PI * 2, false, 0.3); sh.holes.push(hole);
  }
  const g = new THREE.ShapeGeometry(sh, 6);
  g.computeBoundingBox(); const bb = g.boundingBox!;
  const p = g.attributes.position as THREE.BufferAttribute, uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i);
    uv.setXY(i, (x - bb.min.x) / (bb.max.x - bb.min.x), (y - bb.min.y) / (bb.max.y - bb.min.y));
    p.setZ(i, -x * x * 0.35 - (y - bb.max.y) * (y - bb.max.y) * 0.05);
  }
  g.computeVertexNormals();
  return g;
}

export function crearTaza(canvas: HTMLCanvasElement): Taza {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const escena = new THREE.Scene();
  const pm = new THREE.PMREMGenerator(renderer);
  escena.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
  escena.environmentIntensity = 0.55;

  const camara = new THREE.PerspectiveCamera(28, 1, 0.1, 120);
  camara.position.set(0, 4.6, 9.5);
  camara.lookAt(0, 0.7, 0);
  escena.add(camara);

  const uniFondo = { uT: { value: 0 }, uAspect: { value: 1 } };
  const fondo = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: uniFondo, vertexShader: fondoVert, fragmentShader: fondoFrag, depthWrite: false, toneMapped: false }));
  fondo.position.z = -60; fondo.renderOrder = -1; camara.add(fondo);

  const ventana = new THREE.DirectionalLight('#fff0d8', 2.6);
  ventana.position.set(-5, 8, 4); ventana.castShadow = true;
  ventana.shadow.mapSize.set(1024, 1024); Object.assign(ventana.shadow.camera, { left: -4, right: 4, top: 4, bottom: -4 }); ventana.shadow.radius = 8; ventana.shadow.bias = -0.0005;
  escena.add(ventana);
  escena.add(new THREE.HemisphereLight('#fff7ea', '#c9b48f', 0.9));
  const rebote = new THREE.DirectionalLight('#ffd4b0', 0.8); rebote.position.set(4, 2, -3); escena.add(rebote);

  const raiz = new THREE.Group(); escena.add(raiz);
  const giro = new THREE.Group(); raiz.add(giro);

  // platillo
  const loza = new THREE.MeshPhysicalMaterial({ color: '#f7f1e6', roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.12, side: THREE.DoubleSide });
  const platillo = new THREE.Mesh(new THREE.LatheGeometry([
    [0, 0], [0.7, 0], [0.75, 0.03], [0.62, 0.06], [0.7, 0.1], [1.5, 0.16], [1.62, 0.24], [1.6, 0.27], [1.45, 0.21], [0.75, 0.13], [0, 0.11],
  ].map(([x, y]) => new THREE.Vector2(x, y - 0.12)), 96), loza);
  platillo.receiveShadow = true; platillo.castShadow = true; giro.add(platillo);

  // taza: exterior esmaltado verde, interior crema
  const esmalte = new THREE.MeshPhysicalMaterial({ color: '#2d5a3f', roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.15, side: THREE.DoubleSide });
  const taza = new THREE.Group(); taza.position.y = 0.02; giro.add(taza);
  const exterior = new THREE.Mesh(new THREE.LatheGeometry([[0, 0.02], [0.5, 0.02], [0.56, 0.06], [0.6, 0.14], [0.98, 1.18], [1.03, 1.26]].map(([x, y]) => new THREE.Vector2(x, y)), 96), esmalte);
  const interior = new THREE.Mesh(new THREE.LatheGeometry([[1.03, 1.26], [1.0, 1.29], [0.96, 1.24], [0.6, 0.24], [0.4, 0.2], [0, 0.19]].map(([x, y]) => new THREE.Vector2(x, y)), 96), loza);
  const asa = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.075, 18, 48, Math.PI * 1.15), esmalte);
  asa.rotation.z = -Math.PI * 0.57; asa.position.set(0.98, 0.72, 0);
  [exterior, interior, asa].forEach((m) => { m.castShadow = true; m.receiveShadow = true; taza.add(m); });

  // superficie del café
  const uniLiq = { uLeche: { value: 1 }, uArte: { value: 1 }, uT: { value: 0 } };
  const liquido = new THREE.Mesh(new THREE.CircleGeometry(1, 72), new THREE.ShaderMaterial({ uniforms: uniLiq, vertexShader: liqVert, fragmentShader: liqFrag }));
  liquido.rotation.x = -Math.PI / 2; taza.add(liquido);
  const radioEn = (y: number) => 0.6 + ((0.96 - 0.6) * (y - 0.24)) / (1.24 - 0.24) - 0.005;

  // vapor
  const texVapor = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d')!; const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
  const vapores = Array.from({ length: 26 }, () => {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: texVapor, transparent: true, depthWrite: false, opacity: 0 }));
    taza.add(s); return { s, t: rnd(), x: (rnd() - 0.5) * 0.8, z: (rnd() - 0.5) * 0.8, v: 0.12 + rnd() * 0.1 };
  });

  // granos de café
  const mGrano = new THREE.MeshPhysicalMaterial({ color: '#4a2a17', roughness: 0.35, clearcoat: 0.4 });
  const mSurco = new THREE.MeshStandardMaterial({ color: '#1e100a', roughness: 0.8 });
  const granos = Array.from({ length: 16 }, (_, i) => {
    const g = new THREE.Group();
    const cuerpo = new THREE.Mesh(new THREE.SphereGeometry(0.15, 20, 14), mGrano); cuerpo.scale.set(1, 0.68, 0.78); g.add(cuerpo);
    const surco = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.012, 6, 20, Math.PI), mSurco); surco.rotation.set(Math.PI / 2, 0, Math.PI / 2); surco.position.y = 0.095; surco.scale.set(1, 0.4, 1); g.add(surco);
    g.castShadow = true; raiz.add(g);
    return { g, a: (i / 16) * Math.PI * 2, r: 1.9 + rnd() * 0.7, y: 0.4 + rnd() * 1.8, rot: new THREE.Vector3(rnd() * 6, rnd() * 6, rnd() * 6) };
  });

  // hojas de monstera flotando
  const gM = geoMonstera(), mM = new THREE.MeshStandardMaterial({ map: texHoja(), roughness: 0.5, side: THREE.DoubleSide });
  const hojas = [
    [-3.4, 2.6, -2.5, 1.3, 0.6], [3.6, 2.2, -3, 1.1, -0.8], [-3.0, -0.6, -1.2, 0.9, 2.2], [3.2, -0.3, 0.2, 0.8, -2.0], [0.4, 3.5, -4.5, 1.4, 0.2], [-1.8, 3.2, 1.5, 0.55, 1.0],
  ].map(([x, y, z, s, r]) => {
    const m = new THREE.Mesh(gM, mM); m.position.set(x, y, z); m.scale.setScalar(s); m.rotation.set(-0.6 + rnd() * 0.4, r, r * 0.5); m.castShadow = true; escena.add(m);
    return { m, base: m.position.clone(), rot: m.rotation.clone(), f: rnd() * 6 };
  });

  const estado: Taza = {
    proceso: 1, apartar: 0,
    pose: { x: 0.5, y: 0.6, escala: 1, giro: 0, inclinar: 0 },
    activo: (v) => { corriendo = v; if (v) bucle(); },
  };

  let W = 1, H = 1;
  const medir = () => {
    W = canvas.clientWidth; H = canvas.clientHeight;
    renderer.setSize(W, H, false);
    camara.aspect = W / H; camara.updateProjectionMatrix();
    const alto = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * 60;
    fondo.scale.set(alto * camara.aspect * 1.02, alto * 1.02, 1);
    uniFondo.uAspect.value = camara.aspect;
  };
  medir(); addEventListener('resize', medir);

  const raton = { x: 0, y: 0, sx: 0, sy: 0 };
  addEventListener('pointermove', (e) => { raton.x = e.clientX / innerWidth - 0.5; raton.y = e.clientY / innerHeight - 0.5; });
  const quieto = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reloj = new THREE.Clock();
  let corriendo = true, pedido = false;
  function bucle() { if (pedido) return; pedido = true; requestAnimationFrame(() => { pedido = false; if (corriendo) { cuadro(); bucle(); } }); }

  function cuadro() {
    const t = reloj.getElapsedTime();
    uniFondo.uT.value = t; uniLiq.uT.value = t;
    const pr = estado.proceso;

    // fases
    const lleno = ss(0.18, 0.42, pr);        // espresso cayendo
    const leche = ss(0.45, 0.66, pr);        // leche
    const arte = ss(0.66, 0.92, pr);         // dibujo
    const nivel = 0.24 + lleno * 0.42 + leche * 0.5;
    liquido.position.y = nivel; liquido.scale.setScalar(radioEn(nivel));
    liquido.visible = lleno > 0.01;
    uniLiq.uLeche.value = leche; uniLiq.uArte.value = arte;

    // granos: orbitan, luego caen en espiral a la taza
    const caer = ss(0.06, 0.24, pr);
    granos.forEach((b, i) => {
      const vis = pr < 0.26;
      b.g.visible = vis;
      if (!vis) return;
      const a = b.a + t * 0.35 + caer * 4;
      const r = b.r * (1 - caer);
      b.g.position.set(Math.cos(a) * r, THREE.MathUtils.lerp(b.y, 1.0, caer) + Math.sin(t + i) * 0.08 * (1 - caer), Math.sin(a) * r);
      b.g.rotation.set(b.rot.x + t * 0.8, b.rot.y + t * 0.6, b.rot.z);
      b.g.scale.setScalar(1 - caer * 0.9);
    });

    // vapor solo con café caliente
    const calor = lleno;
    vapores.forEach((v) => {
      v.t = (v.t + 0.004 + v.v * 0.01) % 1;
      const y = nivel + 0.1 + v.t * 2.2;
      v.s.position.set(v.x + Math.sin(t * 0.8 + v.t * 6) * 0.25 * v.t, y, v.z);
      const k = 0.3 + v.t * 1.1; v.s.scale.set(k, k, k);
      (v.s.material as THREE.SpriteMaterial).opacity = (quieto ? 0 : 1) * calor * Math.sin(Math.PI * v.t) * 0.28;
    });

    // hojas
    hojas.forEach((h) => {
      const ap = estado.apartar;
      h.m.position.set(h.base.x * (1 + ap * 0.7) + Math.sin(t * 0.3 + h.f) * 0.15, h.base.y + ap * (h.base.y > 1 ? 1.2 : -1.2) + Math.sin(t * 0.45 + h.f) * 0.2, h.base.z);
      h.m.rotation.set(h.rot.x + Math.sin(t * 0.4 + h.f) * 0.12, h.rot.y + Math.sin(t * 0.2 + h.f) * 0.2, h.rot.z);
    });

    // pose
    const altoV = 2 * Math.tan(THREE.MathUtils.degToRad(camara.fov / 2)) * camara.position.length();
    const anchoV = altoV * camara.aspect;
    const p = estado.pose;
    const ajuste = Math.min(1, camara.aspect / 0.85);
    raiz.scale.setScalar(p.escala * ajuste);
    raiz.position.set((p.x - 0.5) * anchoV, (0.5 - p.y) * altoV * 0.85 + 0.6, 0);
    raton.sx += (raton.x - raton.sx) * 0.05; raton.sy += (raton.y - raton.sy) * 0.05;
    raiz.rotation.x = p.inclinar + raton.sy * 0.1;
    giro.rotation.y = p.giro + raton.sx * 0.5 + (quieto ? 0 : Math.sin(t * 0.3) * 0.12);

    renderer.render(escena, camara);
  }
  bucle();
  return estado;
}
